# Integração kart-endurance → kartrace-manager

Ficheiros prontos para copiar por cima dos existentes no teu repositório
(mantém a mesma estrutura de pastas). Todos passaram `tsc --noEmit`, `eslint`
e `vite build` sem erros contra o teu repositório real.

## O que muda

**Novo:** `src/lib/kartFeed/kartFeedClient.ts`
Cliente WebSocket + REST que liga a app ao backend Python (`kart-endurance/`).
Não usa Supabase — fala diretamente com o backend. Se as variáveis de
ambiente não estiverem definidas, fica inativo sem rebentar nada (ver abaixo).

**Alterado:** `src/components/race/KartsPanel.tsx` (Módulo A — a tua equipa)
Mostra a categoria ao vivo (Bom/Médio/Mau) ao lado de cada kart registado,
com um botão "Usar automático" que aplica a sugestão. **Não substitui a
escolha manual sozinho** — é sempre um clique de confirmação, para nunca
sobrescreveres uma classificação que já tenhas ajustado à mão.

**Novo:** `src/components/race/StaffQueuePanel.tsx` + rota
`src/routes/_authenticated/staff-queue.tsx` (Módulo B — staff do evento)
Fila de Espera/Triagem, Fila Vermelha, Fila Azul, sorteio e gestão de
avarias — tudo em tempo real. Acesso restrito a administradores, seguindo
exatamente o mesmo padrão do `admin.tsx`.

**Alterado:** `src/components/race/TeamHeader.tsx`
Novo botão "Karts" na barra superior (só visível para admins) que leva a
`/staff-queue`.

## Como aplicar

1. Copia os 5 ficheiros deste pacote para os caminhos correspondentes no teu
   repositório (substitui os 3 já existentes, cria os 2 novos).
2. Adiciona ao `.env` (e ao ambiente de produção, quando fores fazer deploy):

```
VITE_KART_BACKEND_WS_URL=ws://localhost:8000/ws
VITE_KART_BACKEND_HTTP_URL=http://localhost:8000
```

   Sem estas variáveis, os dois módulos ficam "desligados" de forma
   controlada — não há erro, o `KartsPanel` simplesmente não mostra o badge
   ao vivo, e a página `/staff-queue` mostra uma mensagem a explicar que
   falta configurar.

3. Corre `npm run dev` (o TanStack Router gera automaticamente a rota nova
   no `routeTree.gen.ts` — já testei isto, funciona sem passos extra).
4. Em paralelo, corre o backend Python (`kart-endurance/server.py`) e,
   quando tiveres os seletores confirmados, o `browser_adapter.py`.

## Nota sobre produção

`ws://localhost:8000` só funciona em desenvolvimento local. Para usar isto
num evento real, o backend Python (`server.py` + `browser_adapter.py`) tem
de estar acessível publicamente (ex.: numa VM com IP fixo, atrás de HTTPS/WSS
— sugiro um túnel como Cloudflare Tunnel ou um deploy simples numa VM/
Fly.io/Render, já que o `browser_adapter.py` corre um browser headless e não
serve para correr em edge functions). Quando estiveres a preparar isso,
digo-te os passos concretos consoante a opção que escolheres.
